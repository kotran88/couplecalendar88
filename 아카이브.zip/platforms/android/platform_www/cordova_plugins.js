cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "cordova-plugin-device.device",
    "file": "plugins/cordova-plugin-device/www/device.js",
    "pluginId": "cordova-plugin-device",
    "clobbers": [
      "device"
    ]
  },
  {
    "id": "cordova-plugin-inappbrowser.inappbrowser",
    "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
    "pluginId": "cordova-plugin-inappbrowser",
    "clobbers": [
      "cordova.InAppBrowser.open",
      "window.open"
    ]
  },
  {
    "id": "cordova-plugin-ionic-keyboard.keyboard",
    "file": "plugins/cordova-plugin-ionic-keyboard/www/android/keyboard.js",
    "pluginId": "cordova-plugin-ionic-keyboard",
    "clobbers": [
      "window.Keyboard"
    ]
  },
  {
    "id": "cordova-plugin-kakao-sdk.AuthConstant",
    "file": "plugins/cordova-plugin-kakao-sdk/www/AuthConstant.js",
    "pluginId": "cordova-plugin-kakao-sdk",
    "clobbers": [
      "AuthConstant"
    ]
  },
  {
    "id": "cordova-plugin-kakao-sdk.KakaoCordovaSDK",
    "file": "plugins/cordova-plugin-kakao-sdk/www/KakaoCordovaSDK.js",
    "pluginId": "cordova-plugin-kakao-sdk",
    "clobbers": [
      "KakaoCordovaSDK"
    ]
  },
  {
    "id": "cordova-plugin-naver.Naver",
    "file": "plugins/cordova-plugin-naver/www/naver-native.js",
    "pluginId": "cordova-plugin-naver",
    "clobbers": [
      "Naver"
    ]
  },
  {
    "id": "cordova-plugin-splashscreen.SplashScreen",
    "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
    "pluginId": "cordova-plugin-splashscreen",
    "clobbers": [
      "navigator.splashscreen"
    ]
  },
  {
    "id": "cordova-plugin-statusbar.statusbar",
    "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
    "pluginId": "cordova-plugin-statusbar",
    "clobbers": [
      "window.StatusBar"
    ]
  },
  {
    "id": "cordova-wheel-selector-plugin.plugin",
    "file": "plugins/cordova-wheel-selector-plugin/www/selectorplugin.js",
    "pluginId": "cordova-wheel-selector-plugin",
    "clobbers": [
      "SelectorCordovaPlugin"
    ],
    "runs": true
  },
  {
    "id": "cordova-plugin-datepicker.DatePicker",
    "file": "plugins/cordova-plugin-datepicker/www/android/DatePicker.js",
    "pluginId": "cordova-plugin-datepicker",
    "clobbers": [
      "datePicker"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-device": "2.0.2",
  "cordova-plugin-inappbrowser": "3.0.0",
  "cordova-plugin-ionic-keyboard": "2.1.3",
  "cordova-plugin-kakao-sdk": "3.0.0",
  "cordova-plugin-naver": "1.0.0",
  "cordova-plugin-splashscreen": "5.0.2",
  "cordova-plugin-statusbar": "2.4.2",
  "cordova-plugin-whitelist": "1.3.3",
  "cordova-wheel-selector-plugin": "1.0.0",
  "cordova-plugin-datepicker": "0.9.3"
};
// BOTTOM OF METADATA
});