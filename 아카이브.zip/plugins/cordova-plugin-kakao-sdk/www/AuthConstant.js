
module.exports = {
 
  AuthTypes: {
    AuthTypeTalk: 1,
    AuthTypeStory: 2,
    AuthTypeAccount: 3
  }
};