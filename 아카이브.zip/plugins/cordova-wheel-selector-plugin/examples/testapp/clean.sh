#!/bin/sh

rm -rf ./hooks/ ./node_modules/ ./platforms/ ./res/ ./resources/android ./resources/ios ./www/lib ./plugins
