#!/bin/sh

#get the released plugin in npm registry
cordova plugin rm cordova-wheel-selector-plugin
cordova plugin add cordova-wheel-selector-plugin
